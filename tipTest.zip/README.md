# tipcalculator
Adey's Homework

I want the 3 week class. I want to get deep enough to be dangerous. 

See my gif of the calc here:
https://knowledgelink.kdc.capitalone.com/kl/livelink.exe/Open/1236767792

But be ever more impressed that I have a short link from knowledge link. 
